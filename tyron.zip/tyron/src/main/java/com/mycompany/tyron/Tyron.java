/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tyron;

/**
 *
 * @author CL2~PC37
 */
public class Tyron {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("Tyron Jay Gonzales");
    }
}